import RiskCalc from './RiskCalc'

export default function Home() {
  return <RiskCalc />
}
