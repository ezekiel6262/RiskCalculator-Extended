export const metadata = {
  title: 'Extended | Position Risk Calculator',
  description: 'Perp trading risk analysis tool by Extended Protocol',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#0a0a0a' }}>{children}</body>
    </html>
  )
}
