export const metadata = {
  title: 'Extended | Ecosystem Tools',
  description: 'Position Risk Calculator & Whale Monitor for Extended Protocol — Perpetuals DEX on Starknet',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#0a0a0a' }}>{children}</body>
    </html>
  )
}
